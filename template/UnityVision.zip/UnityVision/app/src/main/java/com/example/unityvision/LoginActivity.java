package com.example.unityvision;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.view.View;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void login(View view) {
        TextView password = findViewById(R.id.password);
        String pwStr = password.getText().toString();
        TextView myError = findViewById(R.id.error);
        TextView email = findViewById(R.id.email);
        String eStr = email.getText().toString();

        // Validate email and password (e.g., check for empty fields)
        if (TextUtils.isEmpty(eStr) || TextUtils.isEmpty(pwStr)) {
            myError.setText("Please enter both email and password.");
            myError.setVisibility(View.VISIBLE);
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        myError.setText("Please enter both email and password.");
                        myError.setVisibility(View.VISIBLE);
                        Intent intent = new Intent(getApplicationContext(), ProfileActivity.class);
                        startActivity(intent);
                    }
                });

                // Replace "YOUR_API_ENDPOINT" with the actual endpoint URL to check user credentials
            /* String url = "YOUR_API_ENDPOINT";

            // Create JSON object with email and password
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("email", eStr);
                jsonObject.put("password", pwStr);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            // Create a request
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                    Request.Method.POST,
                    url,
                    jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            // Handle successful response (e.g., login successful)
                            // Start ProfileActivity
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    // Clear error messages and hide error TextView
                                    myError.setText("");
                                    myError.setVisibility(View.GONE);
                                    Intent intent = new Intent(getApplicationContext(), ProfileActivity.class);
                                    startActivity(intent);
                                }
                            });
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // Handle error response (e.g., login failed)
                            // Display error message in TextView
                            final String errorMessage;
                            if (error.networkResponse != null && error.networkResponse.data != null) {
                                errorMessage = new String(error.networkResponse.data);
                            } else {
                                errorMessage = "Unknown error occurred.";
                            }
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    myError.setText(errorMessage);
                                    myError.setVisibility(View.VISIBLE);
                                }
                            });
                        }
                    });

            // Add the request to the RequestQueue
            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            requestQueue.add(jsonObjectRequest); */
            }
        }).start();
    }
    public void password(View view){
        TextView passwordTextView = findViewById(R.id.password);

        // Get the current transformation method
        TransformationMethod currentMethod = passwordTextView.getTransformationMethod();

        // Toggle between showing and hiding the password
        if (currentMethod instanceof PasswordTransformationMethod) {
            // Show the password
            passwordTextView.setTransformationMethod(null);
        } else {
            // Hide the password
            passwordTextView.setTransformationMethod(new PasswordTransformationMethod());
        }
    }
}