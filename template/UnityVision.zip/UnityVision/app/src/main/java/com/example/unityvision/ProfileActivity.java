package com.example.unityvision;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }

    public void password(View view){
            TextView passwordTextView = findViewById(R.id.password);

            // Get the current transformation method
            TransformationMethod currentMethod = passwordTextView.getTransformationMethod();

            // Toggle between showing and hiding the password
            if (currentMethod instanceof PasswordTransformationMethod) {
                // Show the password
                passwordTextView.setTransformationMethod(null);
            } else {
                // Hide the password
                passwordTextView.setTransformationMethod(new PasswordTransformationMethod());
            }
    }
    public void picture(View view) {
        // Check if the CAMERA permission has been granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission has not been granted yet, request it
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA},
                    100);
        } else {
            // Permission has already been granted, proceed with the camera operation
            startCamera();
        }
    }

    private void startCamera() {
        // Create an intent to launch the camera app
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, 101);
        } else {
            // Handle the case where the camera app is not available
            Toast.makeText(this, "No camera app found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            ImageView imageView = findViewById(R.id.face);
            imageView.setImageBitmap(imageBitmap);

            // Call the send method to upload the image to the API
            send(imageBitmap);
        }
    }

    private void send(final Bitmap imageBitmap) {
       // new Thread(new Runnable() {
//            @Override
//            public void run() {
//                // Convert the Bitmap to a base64 string
//                ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
//                byte[] imageBytes = baos.toByteArray();
//                String base64Image = Base64.encodeToString(imageBytes, Base64.DEFAULT);
//
//                // Make a PUT request to your AWS API with the base64Image
//                sendImageToAWS(base64Image);
//            }
//        }).start();
        TextView thanks = findViewById(R.id.thanks);
        thanks.setVisibility(View.VISIBLE);
    }

    private void sendImageToAWS(String base64Image) {
        // Replace "YOUR_API_ENDPOINT" with the actual endpoint URL to upload the image
        String url = "YOUR_API_ENDPOINT";

        // Create JSON object with the base64Image
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("image", base64Image);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Create a request
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.PUT,
                url,
                jsonObject,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Handle successful response
                        // (e.g., image uploaded successfully)
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle error response
                        // (e.g., error occurred while uploading image)
                    }
                });

        // Add the request to the RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(jsonObjectRequest);
    }

}
