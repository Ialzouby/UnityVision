package com.example.unityvision;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class SignupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
    }


    public void signup(View view) {
        TextView password = findViewById(R.id.password);
        TextView confirm = findViewById(R.id.confirm);
        String pwStr = password.getText().toString();
        String cStr = confirm.getText().toString();
        TextView error = findViewById(R.id.error);
        TextView email = findViewById(R.id.email);
        String eStr = email.getText().toString();

        if (pwStr.equals(cStr)) {
            error.setVisibility(View.GONE);

//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    // Replace "YOUR_API_ENDPOINT" with the actual endpoint URL
//                    String url = "YOUR_API_ENDPOINT";
//
//                    // Create JSON object with username and password
//                    Log.d("Request", "Request URL: " + url);
//                    JSONObject jsonObject = new JSONObject();
//                    try {
//                        jsonObject.put("email", eStr);
//                        jsonObject.put("password", pwStr);
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
//
//                    // Create a request
//                    JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
//                            Request.Method.PUT,
//                            url,
//                            jsonObject,
//                            new Response.Listener<JSONObject>() {
//                                @Override
//                                public void onResponse(JSONObject response) {
//                                    // Handle successful response
//                                    // Start ProfileActivity
//                                    navigateToProfileActivityOnMainThread();
//                                }
//                            },
//                            new Response.ErrorListener() {
//                                @Override
//                                public void onErrorResponse(VolleyError error) {
//                                    // Handle error
//                                    showErrorOnMainThread();
//                                }
//                            });
//
//                    // Add the request to the RequestQueue
//                    RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
//                    requestQueue.add(jsonObjectRequest);
//                }
//            }).start();
            navigateToProfileActivityOnMainThread();
        } else {
            error.setVisibility(View.VISIBLE);
        }
    }

    // Helper method to show error message on the main UI thread
    private void showErrorOnMainThread() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // Show error message on the main UI thread (e.g., error.setVisibility(View.VISIBLE);)
            }
        });
    }

    // Helper method to navigate to ProfileActivity on the main UI thread
    private void navigateToProfileActivityOnMainThread() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SignupActivity.this, ProfileActivity.class);
                startActivity(intent);

            }
        });
    }
    public void password(View view){
        TextView passwordTextView = findViewById(R.id.password);

        // Get the current transformation method
        TransformationMethod currentMethod = passwordTextView.getTransformationMethod();

        // Toggle between showing and hiding the password
        if (currentMethod instanceof PasswordTransformationMethod) {
            // Show the password
            passwordTextView.setTransformationMethod(null);
        } else {
            // Hide the password
            passwordTextView.setTransformationMethod(new PasswordTransformationMethod());
        }
    }
    public void passwordC(View view){
        TextView passwordTextView = findViewById(R.id.confirm);

        // Get the current transformation method
        TransformationMethod currentMethod = passwordTextView.getTransformationMethod();

        // Toggle between showing and hiding the password
        if (currentMethod instanceof PasswordTransformationMethod) {
            // Show the password
            passwordTextView.setTransformationMethod(null);
        } else {
            // Hide the password
            passwordTextView.setTransformationMethod(new PasswordTransformationMethod());
        }
    }
}
